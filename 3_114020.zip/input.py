import stdio

n=int(4)
total=0
for i in range (n):
    total+=stdio.readint()
print('sum is %s'%total)