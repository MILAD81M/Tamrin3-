import math
def hypot(a,b):
    return math.sqrt(a*a+b*b)